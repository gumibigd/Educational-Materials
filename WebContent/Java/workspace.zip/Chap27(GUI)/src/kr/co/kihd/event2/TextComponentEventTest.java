package kr.co.kihd.event2;

public class TextComponentEventTest {

	public static void main(String[] args) {
		TextComponentTest2 tEvent = 
				new TextComponentTest2("Text컴포넌트");
		tEvent.textComponentShow();

	}

}
