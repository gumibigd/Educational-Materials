package kr.co.kihd.event;

public class TextFieldEventTest {
	public static void main(String[] args) {
		TextFieldEvent tEvent = new TextFieldEvent("로그인");
		tEvent.textFieldShow();
	}
}
