# 2.설악산 근방의 지도 보기

# 지점의 경도 위도 
gc <- geocode(enc2utf8("설악산"))
gc

# 경도와 위도를 숫자로.
cen <- as.numeric(gc)
cen
map <- get_googlemap(center = cen,  #중심점좌표
                     zoom = 13,      #지도 확대 정도
                     size = c(640,640), #지도크기
                     maptype = "hybrid"  #지도 유형
                     )
ggmap(map)


# 3.경도와 위도 값을 입력하여 지도 보기

# cen <- c(-118.2333248, 34.085015)
# cen <- c(128.3481734, 36.1141266)
cen <- c(127.09296, 37.09936 )



map <- get_googlemap(center = cen,
                     zoom = 13, 
                     maptype = "roadmap")
ggmap(map)

# 36.1141266,128.3481734

