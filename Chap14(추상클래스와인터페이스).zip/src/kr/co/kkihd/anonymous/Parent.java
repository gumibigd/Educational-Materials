package kr.co.kkihd.anonymous;

public class Parent {

	public Parent() {
		System.out.println("조상 생성자");
	}
	
	public void method() {
		System.out.println("Parent 메서드");
	}
}
