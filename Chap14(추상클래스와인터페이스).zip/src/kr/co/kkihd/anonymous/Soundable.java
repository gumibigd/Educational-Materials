package kr.co.kkihd.anonymous;

//인터페이스에 추상메서드가 1개만 오로지 존재하면 함수적 인터페이스.(람다식)
public interface Soundable {
	public void sound();
}
