package kr.co.kihd.interfacee2;

public interface RemoteControl {

	//상수 (static final)
	int MAX_VOLUMN = 10;
	int MIN_VOLUMN = 0;
	
	//추상메서드 3개 선언 (abstract)
	public void turnOn();
	public void turnOff();
	public void setVolume(int volume);
}
