package kr.co.kihd.interfacee3;

public interface Vehiclable {

	//추상메서드 3개를 선언 
	public void run();
	public void stop();
	public void setSpeed(int speed);
}
