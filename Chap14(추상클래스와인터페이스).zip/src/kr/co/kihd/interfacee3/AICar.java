package kr.co.kihd.interfacee3;

public class AICar {

}
